// Importation des modules nécessaires
const express = require('express');
const http = require('http'); // Nécessaire pour utiliser socket.io avec un serveur HTTP
const { Server } = require('socket.io');
const path = require('path');

// Création de l'application Express
const app = express();

// Création du serveur HTTP basé sur notre app Express
const server = http.createServer(app);

// Initialisation de Socket.IO avec le serveur
const io = new Server(server);

// Définir le dossier "public" pour servir les fichiers statiques (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Quand un client se connecte
io.on('connection', (socket) => {
  console.log('Un utilisateur est connecté');

  // Quand le client envoie un message (événement "chat message")
  socket.on('chat message', (data) => {
    // On rediffuse ce message à tous les clients connectés
    io.emit('chat message', data);
  });

  // Quand un utilisateur se déconnecte
  socket.on('disconnect', () => {
    console.log('Un utilisateur s\'est déconnecté');
  });
});

// Démarrage du serveur sur le port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Serveur lancé sur http://localhost:${PORT}`);
});
