// Connexion au serveur via Socket.IO
const socket = io();

// Sélection des éléments HTML
const loginContainer = document.getElementById('login-container');
const chatBox = document.getElementById('chat-box');
const usernameInput = document.getElementById('username');
const enterChatBtn = document.getElementById('enter-chat');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const messagesList = document.getElementById('messages');

// Variable pour stocker le pseudo de l'utilisateur
let username = "";

// Quand on clique sur "Entrer"
enterChatBtn.addEventListener('click', () => {
  const enteredName = usernameInput.value.trim();
  if (enteredName !== "") {
    username = enteredName;
    loginContainer.style.display = "none"; // Masquer la zone de login
    chatBox.style.display = "block"; // Afficher la zone de chat

    // Afficher un message de bienvenue dans le chat
    const welcome = document.createElement('li');
    welcome.textContent = `👋 Bienvenue ${username} !`;
    messagesList.appendChild(welcome);
  }
});

// Quand on envoie un message
messageForm.addEventListener('submit', (e) => {
  e.preventDefault(); // Empêche le rechargement de la page

  const message = messageInput.value.trim();
  if (message !== "") {
    // On envoie un objet contenant le pseudo et le message au serveur
    socket.emit('chat message', { username, message });
    messageInput.value = ""; // Réinitialiser le champ de message
  }
});

// Quand on reçoit un message du serveur
socket.on('chat message', (data) => {
  const item = document.createElement('li');

  // Afficher le pseudo suivi du message
  item.textContent = `${data.username} : ${data.message}`;

  // Ajouter le message à la liste
  messagesList.appendChild(item);

  // Faire défiler la liste vers le bas automatiquement
  messagesList.scrollTop = messagesList.scrollHeight;
});
